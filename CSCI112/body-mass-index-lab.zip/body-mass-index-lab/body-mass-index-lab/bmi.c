//
//  bmi.c
//  body-mass-index-lab
//
//  Created by Shana Moore on 9/26/17.
//  Copyright © 2017 Shana Moore. All rights reserved.
/*  Construct a C program which includes a function, calculateBMI(), that prompts the user to input a weight, in pounds, and height, in inchese, and then calculates and displays the body mass index and classification. */

#include <stdio.h>
FILE *fp;

int calculateBMI(void); // function prototype

int main(void) {
    // Declare variables with appropriate data types
    int i = 0;
    
    fp = NULL;
    
    // Open file and call function, that will output to file
    fp = fopen("csis.txt", "w");
    for (i = 1; i <= 4; ++i){
        calculateBMI();
    }
    
    // Close file
    fclose(fp);
    return 0;
}

int calculateBMI(void){
    // Declare variables with appropriate data types
    double BMI = 0, weightInPounds = 0, heightInInches = 0;

    // Get weight and height from user
    printf("Welcome, friend! Let's calculate your BMI!\n");
    fprintf(fp, "Welcome, friend! Let's calculate your BMI!\n");
    
    printf("Enter your weight (in pounds): ");
    fprintf(fp, "Enter your weight (in pounds): \n");
    scanf("%lf", &weightInPounds);
    fprintf(fp, "The user entered: %f lbs \n", weightInPounds);
    
    printf("Enter your height (in inches): ");
    fprintf(fp, "Enter your height (in inches): \n");
    scanf("%lf", &heightInInches);
    fprintf(fp, "The user entered: %f inches \n", heightInInches);

    // Compute BMI per user's input
    BMI = (weightInPounds * 703) / (heightInInches * heightInInches);
    
    // Display output of user's BMI value and classification and output to files
    if(BMI >= 30.0){
        printf("Your BMI is %.1f and you are obese.\n\n", BMI);
        fprintf(fp, "Your BMI is %.1f and you are obese.\n\n", BMI);
    }
    else if (BMI >= 25.0){
        printf("Your BMI is %.1f and you are overweight.\n\n", BMI);
        fprintf(fp, "Your BMI is %.1f and you are overweight.\n\n", BMI);
    }
    else if (BMI >= 18.5){
        printf("Your BMI is %.1f and you are normal.\n\n", BMI);
        fprintf(fp, "Your BMI is %.1f and you are normal.\n\n", BMI);
    }
    else {
        printf("Your BMI is %.1f and you are underweight.\n\n", BMI);
        fprintf(fp, "Your BMI is %.1f and you are underweight.\n\n", BMI);
    }
    return 0;
}
