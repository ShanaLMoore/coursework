//
//  main.c
//  HelloWorld
//
//  Created by Shana Moore on 8/23/17.
//  Copyright © 2017 Shana Moore. All rights reserved.
//

#include <stdio.h>


int main() {
    //Display the words Hello World in the console
    printf("Hello, World!\n");
    
    //Hold the console window open after code runs
    //system("pause"); is only available for Windows
}
